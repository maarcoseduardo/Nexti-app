import styled from 'styled-components';

export const ContainerDashboard = styled.section`
    display: flex;
    width: 100%;
`;