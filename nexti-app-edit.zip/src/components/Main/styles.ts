import styled from 'styled-components';

export const ContainerMain = styled.div`
    display: flex;
    flex-direction: column;
    width: 100%;
`;